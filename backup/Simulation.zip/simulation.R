get.data = function(demography=list(), T=1) {
  # demographic stuff
  # maybe use leslie??


  demography$population = round(runif(150,0,100))
  demography$in_workforce = demography$population
  demography$in_workforce[65:150] = 0
  demography$in_workforce = demography$in_workforce - round(abs(runif(150,0,demography$in_workforce))) #assume some are out of workforce
  demography$in_workforce[1:15] = 0
  demography$out_workforce = demography$population - demography$in_workforce
  demography$employed = demography$in_workforce 
  demography$employed[demography$employed<0] = 0  
  demography$employed[1:15] = 0
  demography$unemployed = rep(0,150)
  demography$unemployed[1:15] = 0
  demography$in_to_employment = 0.575 # needs to be changed
  demography$out_of_employment = 0.085 # 
  demography$out_of_workforce = 0.02 # # needs to be changed and probably made age and time specific (functions as well)
  demography$in_to_workforce = 0.026 #

  demography$total_jobs = 1400

  demography$fertility = matrix(rep(c(rep(0,16), rep(0.10, 14), rep(0.075, 10), rep(0,110)), T), ncol=T)
  demography$mortality = matrix(rep(c(rep(0.03,5), rep(0.005, 11), rep(0.0075, 14), rep(0.0075,10),rep(0.05,10),rep(0.15,10),rep(0.2,10),rep(0.4,10),rep(0.5,70)), T), ncol=T)
  demography$mortality[150] = 1 # at that age everybody has to die
  

  return (demography)
}

set.data = function(T = 2004-1975) {
  set.seed(1)
  
  
  # the following variables are stock variables per age cohort. They can be changed to include time. For example by defining them as a matrix with columns representing time points
  # population = rep(0,150) # total population divided by age cohorts. 150 cohorts (1 per year of age)
  # employed = rep(0,150) # number of employed. 150 cohorts (1 per year of age)
  # unemployed = rep(0,150) # number of unemployed. 150 cohorts (1 per year of age)
  # out_workforce = rep(0,150) # number of people not in the workforce. 150 cohorts (1 per year of age) 
  # in_workforce = rep(0,150) # number of people in the workforce. 150 cohorts (1 per year of age)
  # open_jobs = rep(0,150) # (will be ignored for now... maybe use later for more complicated simulation) 150 cohorts (1 per year of age)
  
  # the following variables are flow variables per age cohort (see above) 
  #crude_birth_rate = matrix(rep(0,150*T), 150) # each Kohort has a different cbr and it changes potentially with t
  # fertility = matrix(rep(0,150*T), 150) # each Kohort has a different fertility and it changes potentially with t
  # mortality = matrix(rep(0,150*T), 150) # each Kohort has a different mortality and it changes potentially with t
  # out_of_workforce = matrix(rep(0,150*T), 150) # each Kohort has a different behaviour and it changes potentially with t
  # in_to_workforce = matrix(rep(0,150*T), 150) # each Kohort has a different behaviour and it changes potentially with t
  # net_migration = matrix(rep(0,150*T), 150) # net_migration per age cohort and time t
  # in_to_employment = matrix(rep(0,150*T), 150) # each Kohort has a different behaviour and it changes potentially with t
  # out_of_employment = matrix(rep(0,150*T), 150) # each Kohort has a different behaviour and it changes potentially with t
  #population_growth = matrix(rep(0,150*T), 150) # population increases through migration and births...
  
# initializion:
  demography = get.data()
  return (demography)
}

do.simulation = function() {
  start = 1975 #dunno will use more later... 
  end = 2004  
  data = set.data(end-start) # initialize everything
  
  for (t in start:end) {
   # population stuff
    data = deaths(data)
    if (any(data$out_workforce < 0))
      print(paste('NOW:', t))
    #print('data after deaths');print(data$in_workforce)
    data = age(data) # let population age...
    #print('data after age');print(data$in_workforce)
    data = births(data) # put births...
    #print('data after biths');print(data$in_workforce)	
    
  # workforce stuff
    change = move_workforce(data) 
    data = change_employment_on_workforce_change(data, change)
    data$out_workforce = data$out_workforce + change$move_out_workforce - change$move_in_workforce
    data$in_workforce = data$in_workforce + change$move_in_workforce - change$move_out_workforce
    #print('data after move_workforce');print(data$in_workforce)   
    
 # employment effect of workforce movement:   
  # employment stuff
    change = change_employment(data)
    data$unemployed = data$unemployed + change$unemploy - change$employ
    data$employed = data$employed - change$unemploy + change$employ
    
    
    #print(data$in_workforce)
    #print(data$employed)
    #print(data$unemployed)
    
    
    print(paste('t: ',t));
    print(paste('population: ', sum(data$population)))
    print(paste('in workforce: ', sum(data$in_workforce)))
    print(paste('employed: ', sum(data$employed)));
    print(paste('unemployed: ', sum(data$unemployed)));
    print(paste('unemployment rate: ', sum(data$unemployed)/sum(data$in_workforce))); 
  }

  #return (data)
}