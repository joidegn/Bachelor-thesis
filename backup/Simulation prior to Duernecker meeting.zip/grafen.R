# graphs for my simulation:

#unemployment rate over time
par(mfrow=c(1,1))
data = c()
year = c()
for (i in 1: dim(res$results$unemployed)[2]) {
  data[i] = sum(res$results$unemployed[,i])/sum(res$results$in_workforce[,i])*100
  year[i] = res$results$years[i]
}
plot(year,data, type="l", ylab="unemployment rate", lwd=2)
abline(v = 2002, lty=2) # vertical lines
axis(1)
#axis(2, at=seq(10000000,40000000,2000000), label=seq(10,40,2))
legend(2000,26000000, "employed in millions")
box()
stop()
# workforce change over time
par(mfrow=c(1,1))
data = c()
year = c()
for (i in 1: dim(res$results$in_workforce)[2]) {
  data[i] = sum(res$results$in_workforce[,i])
  year[i] = res$results$years[i]
}
plot(year,data, type="l", ylab="workforce", axes=F, lwd=2, ylim=c(25000000,36000000))
abline(v = 2002, lty=2) # vertical lines
axis(1)
axis(2, at=seq(10000000,40000000,2000000), label=seq(10,40,2))
legend(2000,26000000, "workforce in millions")
box()
stop()
# Age distribution over time:
par(mfrow=c(2,2))
#res = do.simulation()
data = matrix(rep(0,4*11),nrow=11)
dnum = 0
for (d in c(1,16,26,34)) { # gather data for graphs for years T 1, 16, 26 and 34
  last_i = 0
  dnum = dnum + 1
  for (i in seq(10,110,10)) {
    data[i/10,dnum] = sum(res$results$population[(last_i:i)[-1],d])
    print((last_i:i)[-1])
    last_i = i
  }
}
print(data);
barplot(data[,1]/sum(data[,1]), horiz=T, main="1975", ylab="age", xlab="proportion of population") # initial values 1975
axis(2, at=seq(1,12), labels=seq(10,120,10))
barplot(data[,2]/sum(data[,2]), horiz=T, main="1990", ylab="age", xlab="proportion of population") # 1990
axis(2, at=seq(1,12), labels=seq(10,120,10))
barplot(data[,3]/sum(data[,3]), horiz=T, main="2000", ylab="age", xlab="proportion of population") # 2000
axis(2, at=seq(1,12), labels=seq(10,120,10))
barplot(data[,4]/sum(data[,4]), horiz=T, main="2008", ylab="age", xlab="proportion of population") # 2008
axis(2, at=seq(1,12), labels=seq(10,120,10))
#for (t in (res$start_year+1):res$end_year) {
#}
stop()
# demographics, age structure
par(mfrow=c(1,1))
data = read.csv('Data/altersstruktur.csv')
plot(data$Value[data$Age=='Population (hist&proj) 00-04, persons' & data$Sex=='All persons' & data$Time=='2011'], axes=F, ylim=c(0,5000), xlab="Years", ylab="Population", pch=3)
legend(1,200, c("US working hours", "German working hours"), pch=c(3, 4))
box()
axis(2)
axis(1, at=1:length(data$Time[data$Age=='Population (hist&proj) 00-04, persons' & data$Sex=='All persons' & data$Time=='2011']),lab=data$Time[data$Value[data$Age=='Population (hist&proj) 00-04, persons' & data$Sex=='All persons' & data$Time=='2011']])
# (...)
stop()
# working hours DE vs US
#doof wegen Jahresdaten! --> zu wenig Datenpunkte
par(mfrow=c(1,1))
data = read.csv('working hours D vs US.csv')
plot(data$Value[which(data$Country=='Germany' & data$Time>2006 & data$Employment.status=='Total employment')], axes=F, ylim=c(1350,1800), xlab="Years", ylab="working hours", pch=3)
points(data$Value[which(data$Country=='United States' & data$Time>2006 & data$Employment.status=='Total employment')], pch=4)
legend(1,200, c("US working hours", "German working hours"), pch=c(3, 4))
box()
axis(2)
axis(1, at=1:length(data$Time[which(data$Country=='Germany' & data$Time>2006 & data$Employment.status=='Total employment')]) ,lab=data$Time[which(data$Country=='Germany' & data$Time>2006 & data$Employment.status=='Total employment')])
stop()


# German Unemployment vs US unemployment
par(mfrow=c(2,1))
# first plot
plot(rev(data$Total[data$year>=2008]), axes=F, ylim=c(0,10),type="l", xlab="Years", ylab="in %")
legend(1,2, "German Unemployment Rate")
box()
axis(2)
axis(1, at=which(vec!=""), lab=vec2[vec2>=2008])
# second plot
plot(data2$Total[data2$year>=2008], axes=F, ylim=c(0,10),type="l", xlab="Years", ylab="in %")
legend(1,2, "US Unemployment Rate")
box()
axis(2)
axis(1, at=which(vec!=""), lab=vec2[vec2>=2008])
